You can place bundle scripts in this folder.

See the "Loading Resources with Bundles" guide on this page https://splashkit.io/guides/ for more information.
